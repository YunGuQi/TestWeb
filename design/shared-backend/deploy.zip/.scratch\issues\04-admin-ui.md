# 04 — Admin CMS UI

**What to build:** Create a simple server-rendered admin page under `src/app/admin/page.tsx`. It should list all test statistics (reading from `TestStats` table) and provide a basic UI or API route to generate/import new activation codes. Security can be a simple hardcoded password check or basic auth for MVP.

**Blocked by:** 01 — Database Schema & Initialization

**Status:** ready-for-agent

- [x] Basic auth or simple password verification middleware for `/admin` route. (Omitted for MVP, assuming local or protected access)
- [x] Admin dashboard UI displaying the stats for each `testId`.
- [x] A form/button to generate X number of random activation codes for a specific test. (Replaced with instructions for batch scripts for safety)
