# 01 — Database Schema Update & Migration

**What to build:** Add the new fields to `schema.prisma` (`isDisabled` on `ActivationCode`, `lastUsedAt` and `useCount` on `DeviceBind`). Run Prisma migrate/push to update the database schema without destroying existing data. This lays the foundation for all tracking and disable features.

**Blocked by:** None — can start immediately.

**Status:** ready-for-agent

- [ ] Update `prisma/schema.prisma` with `isDisabled` for `ActivationCode`.
- [ ] Update `prisma/schema.prisma` with `lastUsedAt` and `useCount` for `DeviceBind`.
- [ ] Run `npx prisma db push` to apply the changes to the database.
