# 03 — Stats and Submit API Endpoints

**What to build:** Create two endpoints for test counting.
1. `GET /api/stats?testId=xxx`: Returns the current total count (baseCount + realCount) for the given test. If the test doesn't exist, return a default/fallback baseCount.
2. `POST /api/submit`: Receives a `testId` and `deviceId`. Increments the `realCount` for that test in a transaction/atomic update, and returns the newly incremented total as the user's specific "completion rank".

**Blocked by:** 01 — Database Schema & Initialization

**Status:** ready-for-agent

- [x] Route handler created at `src/app/api/stats/route.ts` to return total counts.
- [x] Route handler created at `src/app/api/submit/route.ts` to atomic increment `realCount` and return the rank.
- [x] Both endpoints return proper CORS headers.
