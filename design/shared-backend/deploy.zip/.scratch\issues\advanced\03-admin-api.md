# 03 — Admin API for Advanced Actions

**What to build:** Create three new backend API routes for the admin CMS to perform the advanced operations: disabling/enabling a code, fetching detailed device history for a code, and clearing excess devices to stop abuse.

**Blocked by:** 01 — Database Schema Update & Migration

**Status:** ready-for-agent

- [ ] Create `POST /api/admin/code/[id]/disable` that toggles the `isDisabled` boolean on the `ActivationCode`.
- [ ] Create `GET /api/admin/code/[id]/devices` that fetches all `DeviceBind` records for the code, ordered by `createdAt` ASC.
- [ ] Create `POST /api/admin/code/[id]/clear-devices` that fetches all `DeviceBind` records ordered by `createdAt` ASC, keeps the first N (e.g., 3), and deletes all subsequent ones from the database.
