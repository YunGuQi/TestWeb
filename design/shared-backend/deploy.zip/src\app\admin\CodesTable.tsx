'use client';

import { useState } from 'react';

export default function CodesTable({ initialCodes }: { initialCodes: any[] }) {
  const [codes, setCodes] = useState(initialCodes);
  const [loadingCodeId, setLoadingCodeId] = useState<string | null>(null);
  const [devicesModal, setDevicesModal] = useState<{ show: boolean, code: any, devices: any[] }>({ show: false, code: null, devices: [] });

  const handleToggleDisable = async (id: string) => {
    setLoadingCodeId(id);
    try {
      const res = await fetch(`/api/admin/code/${id}/disable`, { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setCodes(codes.map(c => c.id === id ? { ...c, isDisabled: data.isDisabled } : c));
      }
    } catch (e) {
      alert('操作失败');
    } finally {
      setLoadingCodeId(null);
    }
  };

  const handleViewDevices = async (code: any) => {
    try {
      const res = await fetch(`/api/admin/code/${code.id}/devices`);
      const data = await res.json();
      if (data.success) {
        setDevicesModal({ show: true, code, devices: data.devices });
      }
    } catch (e) {
      alert('获取设备记录失败');
    }
  };

  const handleClearDevices = async (id: string) => {
    if (!confirm('确定要清理设备吗？将只保留最早验证的 3 个设备。')) return;
    setLoadingCodeId(id);
    try {
      const res = await fetch(`/api/admin/code/${id}/clear-devices`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ keepCount: 3 })
      });
      const data = await res.json();
      if (data.success) {
        alert(data.message);
        // Optimistically update device count (requires a full refresh for perfect sync but this is ok)
        window.location.reload();
      }
    } catch (e) {
      alert('清理失败');
    } finally {
      setLoadingCodeId(null);
    }
  };

  const handleEditMaxUses = async (code: any) => {
    const newVal = prompt(`请输入新的设备上限 (当前为 ${code.maxUses}):`, code.maxUses.toString());
    if (!newVal) return;
    const maxUses = parseInt(newVal);
    if (isNaN(maxUses) || maxUses < 1) return alert('请输入有效的大于0的数字');
    
    setLoadingCodeId(code.id);
    try {
      const res = await fetch(`/api/admin/code/${code.id}/max-uses`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ maxUses })
      });
      const data = await res.json();
      if (data.success) {
        setCodes(codes.map(c => c.id === code.id ? { ...c, maxUses: data.maxUses } : c));
      } else {
        alert(data.error || '修改失败');
      }
    } catch (e) {
      alert('网络错误');
    } finally {
      setLoadingCodeId(null);
    }
  };

  return (
    <div className="mt-8">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold text-gray-800">卡密详细列表</h2>
        <button 
          onClick={async () => {
            if(!confirm('确定要生成 10 个新的通用激活码吗（上限3台设备）？')) return;
            const res = await fetch('/api/admin/generate', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ count: 10, maxUses: 3 })
            });
            const data = await res.json();
            if(data.success) {
              alert('成功生成 ' + data.count + ' 个激活码！');
              window.location.reload();
            } else {
              alert('生成失败: ' + data.error);
            }
          }}
          className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded font-bold shadow transition-colors"
        >
          + 一键生成 10 个卡密
        </button>
      </div>
      <div className="overflow-x-auto bg-white border border-gray-200 rounded-lg shadow-sm">
        <table className="w-full text-left text-sm text-gray-600">
          <thead className="bg-gray-50 border-b border-gray-200 text-gray-900 font-semibold">
            <tr>
              <th className="p-4">订单编号</th>
              <th className="p-4">项目专属</th>
              <th className="p-4">设备上限</th>
              <th className="p-4">已绑设备数</th>
              <th className="p-4">状态</th>
              <th className="p-4">操作</th>
            </tr>
          </thead>
          <tbody>
            {codes.map(code => (
              <tr key={code.id} className="border-b border-gray-100 hover:bg-gray-50">
                <td className="p-4 font-mono font-medium text-black">{code.code}</td>
                <td className="p-4">{code.testId || '通用'}</td>
                <td className="p-4">
                  <div className="flex items-center gap-2">
                    <span className="font-bold">{code.maxUses}</span>
                    <button onClick={() => handleEditMaxUses(code)} className="text-gray-400 hover:text-blue-500 text-xs border border-gray-200 px-1 rounded shadow-sm bg-white active:scale-95">修改</button>
                  </div>
                </td>
                <td className="p-4">
                  <span className={`font-bold ${(code.devices || []).length > (code.maxUses || 3) ? 'text-red-500' : 'text-green-600'}`}>
                    {(code.devices || []).length}
                  </span>
                </td>
                <td className="p-4">
                  {code.isDisabled ? (
                    <span className="px-2 py-1 text-xs font-bold bg-red-100 text-red-700 rounded">已禁用</span>
                  ) : (
                    <span className="px-2 py-1 text-xs font-bold bg-green-100 text-green-700 rounded">正常</span>
                  )}
                </td>
                <td className="p-4 flex gap-2">
                  <button 
                    onClick={() => handleToggleDisable(code.id)}
                    disabled={loadingCodeId === code.id}
                    className="text-xs px-3 py-1 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded font-medium disabled:opacity-50"
                  >
                    {code.isDisabled ? '解除禁用' : '禁用'}
                  </button>
                  <button 
                    onClick={() => handleViewDevices(code)}
                    className="text-xs px-3 py-1 bg-blue-100 hover:bg-blue-200 text-blue-700 rounded font-medium"
                  >
                    设备记录
                  </button>
                  <button 
                    onClick={() => handleClearDevices(code.id)}
                    disabled={loadingCodeId === code.id || (code.devices || []).length <= 3}
                    className="text-xs px-3 py-1 bg-red-50 hover:bg-red-100 text-red-600 border border-red-200 rounded font-medium disabled:opacity-50"
                  >
                    防白嫖清理(留3)
                  </button>
                </td>
              </tr>
            ))}
            {codes.length === 0 && (
              <tr>
                <td colSpan={6} className="p-8 text-center text-gray-500">暂无任何卡密记录</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {devicesModal.show && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[80vh] flex flex-col overflow-hidden">
            <div className="p-6 border-b border-gray-200 flex justify-between items-center bg-gray-50">
              <h3 className="text-lg font-bold text-gray-900">设备记录 - {devicesModal.code?.code}</h3>
              <button onClick={() => setDevicesModal({ show: false, code: null, devices: [] })} className="text-gray-500 hover:text-black font-bold">X</button>
            </div>
            <div className="p-6 overflow-y-auto">
              <table className="w-full text-left text-sm text-gray-600">
                <thead className="border-b border-gray-200 text-gray-900">
                  <tr>
                    <th className="pb-3">设备标识</th>
                    <th className="pb-3">首次绑定时间</th>
                    <th className="pb-3">最近验证时间</th>
                    <th className="pb-3">总请求次数</th>
                  </tr>
                </thead>
                <tbody>
                  {devicesModal.devices.map((d: any, index: number) => (
                    <tr key={d.id} className="border-b border-gray-100">
                      <td className="py-3 font-mono text-xs">{d.deviceId.substring(0, 16)}...</td>
                      <td className="py-3">{new Date(d.createdAt).toLocaleString()}</td>
                      <td className="py-3">{new Date(d.lastUsedAt).toLocaleString()}</td>
                      <td className="py-3 font-bold">{d.useCount}</td>
                    </tr>
                  ))}
                  {devicesModal.devices.length === 0 && (
                    <tr><td colSpan={4} className="py-6 text-center italic">暂无设备绑定记录</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
