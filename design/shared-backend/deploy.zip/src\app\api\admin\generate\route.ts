import { NextResponse } from 'next/server';
import { db } from '@/lib/tcb';

export async function POST(req: Request) {
  try {
    const { count, maxUses } = await req.json();
    const codes = [];
    
    for (let i = 0; i < count; i++) {
      codes.push({
        id: crypto.randomUUID(),
        code: `CODE-${crypto.randomUUID().substring(0, 8).toUpperCase()}`,
        maxUses: maxUses || 3,
        devices: [],
        isDisabled: false,
        testId: '', // 空表示通用
        createdAt: new Date().toISOString(),
      });
    }

    // CloudBase db collection add supports array insertion
    const res = await db.collection('ActivationCode').add(codes);

    return NextResponse.json({ success: true, count: codes.length });
  } catch (e: any) {
    return NextResponse.json({ success: false, error: e.message });
  }
}
