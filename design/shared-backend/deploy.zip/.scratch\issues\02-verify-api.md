# 02 — Verify API Endpoint (/api/verify)

**What to build:** Create a highly robust API route that receives a `code`, `testId`, and `deviceId`. It should validate the code exists, check if it's applicable to the `testId` (or is a universal code), and register the `deviceId` if it's a new device. It must reject requests where the code has already reached its `maxUses` on different devices. It must include CORS headers to allow cross-origin requests from the frontend test projects.

**Blocked by:** 01 — Database Schema & Initialization

**Status:** ready-for-agent

- [x] Route handler created at `src/app/api/verify/route.ts`.
- [x] Returns 404/400 if the code is invalid or does not match `testId`.
- [x] Returns 200 and registers device if code is valid and under `maxUses`.
- [x] Returns 403 if code is valid but `maxUses` device limit is reached for new devices.
- [x] Returns CORS headers (`Access-Control-Allow-Origin: *`).
