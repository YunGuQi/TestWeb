import { NextResponse } from 'next/server';
import { db } from '@/lib/tcb';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

export async function OPTIONS() {
  return NextResponse.json({}, { headers: corsHeaders });
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { testId, deviceId } = body;

    if (!testId || !deviceId) {
      return NextResponse.json({ error: '缺少必需的参数' }, { status: 400, headers: corsHeaders });
    }

    const _ = db.command;

    // Atomic increment
    await db.collection('TestProject').where({ testId }).update({
      realCount: _.inc(1)
    });

    const getRes = await db.collection('TestProject').where({ testId }).get();
    if (!getRes.data || getRes.data.length === 0) {
      return NextResponse.json({ error: '测试项目不存在' }, { status: 500, headers: corsHeaders });
    }
    
    const project = getRes.data[0];

    return NextResponse.json({ 
      success: true,
      current_rank: (project.baseCount || 0) + (project.realCount || 0)
    }, { status: 200, headers: corsHeaders });

  } catch (error) {
    console.error('Submit error:', error);
    return NextResponse.json({ error: '测试项目不存在或服务器内部错误' }, { status: 500, headers: corsHeaders });
  }
}
