# 01 — Database Schema & Initialization

**What to build:** Initialize the Next.js project and configure Prisma with SQLite. Define the three core tables (`TestStats`, `ActivationCode`, `DeviceBind`) according to the PRD. Ensure that `deviceId` and `codeId` have a unique compound index to prevent double counting. Seed the database with some initial mock data (one generic code, one test-specific code).

**Blocked by:** None — can start immediately

**Status:** ready-for-agent

- [x] Next.js project is initialized (if not already done).
- [x] Prisma is installed and SQLite is configured.
- [x] Prisma schema contains `TestStats`, `ActivationCode`, and `DeviceBind` models.
- [x] Migration is successfully run and database is created.
- [x] Seed script successfully inserts test data.
