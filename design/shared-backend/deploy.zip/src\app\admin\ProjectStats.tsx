'use client';

import { useState } from 'react';

export default function ProjectStats({ projects, allCodes }: { projects: any[], allCodes: any[] }) {
  const [selectedId, setSelectedId] = useState<string>(projects[0]?.id || '');
  
  const totalOrders = allCodes.length;
  const totalUsers = allCodes.reduce((sum, c) => sum + (c.devices || []).length, 0);
  const totalTestCompletions = projects.reduce((sum, p) => sum + (p.realCount || 0), 0);

  const selectedProject = projects.find(p => p.id === selectedId);

  return (
    <div className="mb-8">
      {/* 汇总信息 */}
      <div className="bg-gray-900 text-white p-6 rounded-lg shadow-md mb-6 grid grid-cols-2 md:grid-cols-4 gap-6 items-center">
        <div className="col-span-2 md:col-span-1 md:border-r border-gray-700 md:pr-4">
          <h2 className="text-xl font-bold mb-1">大盘核心数据</h2>
          <p className="text-gray-400 text-sm">收录 {projects.length} 个项目</p>
        </div>
        <div>
          <p className="text-sm text-gray-400 mb-1">总发卡订单数</p>
          <p className="text-3xl font-black text-blue-400">{totalOrders}</p>
        </div>
        <div>
          <p className="text-sm text-gray-400 mb-1">总解锁用户数</p>
          <p className="text-3xl font-black text-green-400">{totalUsers}</p>
        </div>
        <div>
          <p className="text-sm text-gray-400 mb-1">真实总测算次数</p>
          <p className="text-3xl font-black text-purple-400">{totalTestCompletions}</p>
        </div>
      </div>

      {/* 下拉框与单个测试展示 */}
      {projects.length > 0 && (
        <div className="border border-gray-200 p-6 rounded-lg shadow-sm bg-white">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
            <h2 className="font-semibold text-lg text-gray-900">单项测试数据查询</h2>
            <select 
              value={selectedId} 
              onChange={e => setSelectedId(e.target.value)}
              className="border-2 border-gray-300 rounded p-2 text-gray-800 font-medium focus:outline-none focus:border-black max-w-xs w-full sm:w-auto"
            >
              {projects.map(p => (
                <option key={p.id} value={p.id}>{p.name} ({p.testId})</option>
              ))}
            </select>
          </div>
          
          {selectedProject && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-gray-50 p-4 rounded border border-gray-100">
                <p className="text-gray-500 text-sm mb-1">基础访问基数</p>
                <p className="text-xl font-bold text-gray-800">{selectedProject.baseCount || 0}</p>
              </div>
              <div className="bg-gray-50 p-4 rounded border border-gray-100">
                <p className="text-gray-500 text-sm mb-1">真实完成人数</p>
                <p className="text-xl font-bold text-gray-800">{selectedProject.realCount || 0}</p>
              </div>
              <div className="bg-blue-50 p-4 rounded border border-blue-100">
                <p className="text-blue-600 text-sm font-bold mb-1">前端展示总数</p>
                <p className="text-3xl font-black text-blue-700">{(selectedProject.baseCount || 0) + (selectedProject.realCount || 0)}</p>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
