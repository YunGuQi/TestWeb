# 04 — Admin UI Enhancements

**What to build:** Update the admin dashboard (`admin/page.tsx`) to surface the new data and wire up the new API endpoints. Admins need to see if a code is disabled, see its total device count, and click buttons to disable it or clear excess devices.

**Blocked by:** 03 — Admin API for Advanced Actions

**Status:** ready-for-agent

- [ ] Fetch the updated `ActivationCode` records including their nested `devices` array.
- [ ] Render "Status" column (Active vs Disabled) and "Total Uses" / "Devices" info.
- [ ] Add a "Disable/Enable" button for each row.
- [ ] Add a "Clean up" button to clear excess devices.
- [ ] (Optional) Add an expandable details view or modal to list the exact devices with their `createdAt`, `lastUsedAt`, and `useCount`.
