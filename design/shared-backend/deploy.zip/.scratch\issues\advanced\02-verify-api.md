# 02 — Verify API Enhancements

**What to build:** Update the core `/api/verify` route to respect the `isDisabled` flag, and to update `lastUsedAt` and `useCount` on the `DeviceBind` record whenever a device successfully validates (whether it's the first time binding or a subsequent validation).

**Blocked by:** 01 — Database Schema Update & Migration

**Status:** ready-for-agent

- [ ] Fetch the `code` record and check `if (codeRecord.isDisabled)`. If true, return 403 Forbidden with an appropriate error message.
- [ ] When successfully binding a new device, ensure `lastUsedAt` is set to `now()` and `useCount` is `1`.
- [ ] When a previously bound device successfully re-verifies, update its `DeviceBind` record by setting `lastUsedAt = now()` and `useCount = { increment: 1 }`.
