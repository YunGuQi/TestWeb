'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useParams, useRouter } from 'next/navigation';
import { TEST_PROJECTS } from '@/config/projects';

export default function ContentEditor() {
  const params = useParams();
  const router = useRouter();
  const testId = params?.testId as string;
  
  const [activeTab, setActiveTab] = useState<'visual' | 'json'>('visual');
  const [visualTab, setVisualTab] = useState<'questions' | 'results'>('questions');
  const [data, setData] = useState<any>({ testId: '', questions: [], results: [] });
  const [jsonStr, setJsonStr] = useState<string>('');
  
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!testId) return;
    fetch(`/api/admin/content?testId=${testId}`)
      .then(res => res.json())
      .then(fetchedData => {
        setData(fetchedData);
        setJsonStr(JSON.stringify(fetchedData, null, 2));
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setError('加载失败');
        setLoading(false);
      });
  }, [testId]);

  // Sync Visual -> JSON
  const syncToJson = (newData: any) => {
    setData(newData);
    setJsonStr(JSON.stringify(newData, null, 2));
  };

  // Sync JSON -> Visual
  const syncToVisual = (newJson: string) => {
    setJsonStr(newJson);
    try {
      const parsed = JSON.parse(newJson);
      setData(parsed);
      setError(null);
    } catch (e: any) {
      setError(`JSON 格式错误: ${e.message}`);
    }
  };

  const handleSave = async () => {
    setError(null);
    let parsedData;
    try {
      parsedData = JSON.parse(jsonStr);
    } catch (e: any) {
      setError(`JSON 格式错误: ${e.message}`);
      return;
    }

    setSaving(true);
    try {
      const res = await fetch(`/api/admin/content?testId=${testId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(parsedData)
      });
      const resData = await res.json();
      if (resData.success) {
        alert('保存成功！');
      } else {
        setError(resData.error || '保存失败');
      }
    } catch (e) {
      setError('网络错误');
    } finally {
      setSaving(false);
    }
  };

  // --- Visual Editor Handlers ---
  const addQuestion = () => {
    const qId = `q${Date.now()}`;
    const newData = { ...data, questions: [...(data.questions || []), { id: qId, text: '', options: [] }] };
    syncToJson(newData);
  };
  const updateQuestion = (qIndex: number, field: string, val: any) => {
    const newQs = [...(data.questions || [])];
    newQs[qIndex] = { ...newQs[qIndex], [field]: val };
    syncToJson({ ...data, questions: newQs });
  };
  const removeQuestion = (qIndex: number) => {
    const newQs = [...(data.questions || [])];
    newQs.splice(qIndex, 1);
    syncToJson({ ...data, questions: newQs });
  };

  const addOption = (qIndex: number) => {
    const oId = `o${Date.now()}`;
    const newQs = [...(data.questions || [])];
    const prevOptions = newQs[qIndex].options || [];
    let template: any = { id: oId, text: '', score: 0 };
    if (prevOptions.length > 0) {
      template = { ...prevOptions[0], id: oId, text: '' };
      for (const k in template) {
        if (k !== 'id' && k !== 'text') {
          template[k] = typeof template[k] === 'number' ? 0 : '';
        }
      }
    }
    newQs[qIndex].options = [...prevOptions, template];
    syncToJson({ ...data, questions: newQs });
  };
  const updateOption = (qIndex: number, oIndex: number, field: string, val: any) => {
    const newQs = [...(data.questions || [])];
    const newOpts = [...(newQs[qIndex].options || [])];
    newOpts[oIndex] = { ...newOpts[oIndex], [field]: val };
    newQs[qIndex].options = newOpts;
    syncToJson({ ...data, questions: newQs });
  };
  const removeOption = (qIndex: number, oIndex: number) => {
    const newQs = [...(data.questions || [])];
    const newOpts = [...(newQs[qIndex].options || [])];
    newOpts.splice(oIndex, 1);
    newQs[qIndex].options = newOpts;
    syncToJson({ ...data, questions: newQs });
  };

  const addResult = () => {
    const rId = `r${Date.now()}`;
    let template: any = { id: rId, title: '', description: '', minScore: 0, maxScore: 0 };
    if (data.results && data.results.length > 0) {
      template = { ...data.results[0], id: rId, title: '', description: '' };
      for (const k in template) {
        if (k !== 'id' && k !== 'title' && k !== 'description') {
          template[k] = typeof template[k] === 'number' ? 0 : '';
        }
      }
    }
    const newData = { ...data, results: [...(data.results || []), template] };
    syncToJson(newData);
  };
  const updateResult = (rIndex: number, field: string, val: any) => {
    const newRs = [...(data.results || [])];
    newRs[rIndex] = { ...newRs[rIndex], [field]: val };
    syncToJson({ ...data, results: newRs });
  };
  const removeResult = (rIndex: number) => {
    const newRs = [...(data.results || [])];
    newRs.splice(rIndex, 1);
    syncToJson({ ...data, results: newRs });
  };

  return (
    <div className="p-8 font-sans max-w-6xl mx-auto">
      <div className="mb-6 flex justify-between items-center">
        <div className="flex items-center gap-4">
          <h1 className="text-2xl font-bold">测试内容管理</h1>
          {testId && (
            <select 
              value={testId}
              onChange={(e) => {
                if (e.target.value) {
                  router.push(`/admin/content/${e.target.value}`);
                }
              }}
              className="border-2 border-gray-300 rounded p-1.5 text-gray-800 font-medium focus:outline-none focus:border-purple-500 bg-white"
            >
              <option value="" disabled>选择要管理的测试项目...</option>
              {TEST_PROJECTS.map(p => (
                <option key={p.testId} value={p.testId}>{p.name} ({p.testId})</option>
              ))}
            </select>
          )}
        </div>
        <Link href="/admin" className="text-gray-600 hover:text-black transition-colors font-medium">
          &larr; 返回控制台
        </Link>
      </div>

      {loading ? (
        <div className="text-gray-500">加载中...</div>
      ) : (
        <div className="bg-white border border-gray-200 rounded-lg shadow-sm flex flex-col">
          {/* Tabs */}
          <div className="flex border-b border-gray-200 bg-gray-50 rounded-t-lg">
            <button 
              className={`px-6 py-3 font-bold text-sm ${activeTab === 'visual' ? 'bg-white border-t-2 border-purple-600 text-purple-700' : 'text-gray-600 hover:bg-gray-100'}`}
              onClick={() => setActiveTab('visual')}
            >
              可视表单编辑器
            </button>
            <button 
              className={`px-6 py-3 font-bold text-sm ${activeTab === 'json' ? 'bg-white border-t-2 border-purple-600 text-purple-700' : 'text-gray-600 hover:bg-gray-100'}`}
              onClick={() => setActiveTab('json')}
            >
              JSON 源码视图 (支持导入)
            </button>
            <div className="ml-auto p-2 flex items-center">
              {error && <span className="text-red-500 text-sm font-bold mr-4">{error}</span>}
              <button
                onClick={handleSave}
                disabled={saving || !!error}
                className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-1.5 px-6 rounded shadow transition-colors disabled:opacity-50"
              >
                {saving ? '保存中...' : '保存修改'}
              </button>
            </div>
          </div>

          <div className="p-6">
            {activeTab === 'json' && (
              <textarea
                className="w-full h-[700px] p-4 font-mono text-sm border-2 border-gray-300 rounded bg-gray-50 focus:outline-none focus:border-purple-500"
                value={jsonStr}
                onChange={(e) => syncToVisual(e.target.value)}
                spellCheck={false}
              />
            )}

            {activeTab === 'visual' && (
              <div className="flex flex-col">
                {/* Sub-tabs for Visual Editor */}
                <div className="flex border-b border-gray-200 mb-6 bg-white sticky top-0 z-20 shadow-sm">
                  <button 
                    onClick={() => setVisualTab('questions')}
                    className={`flex-1 py-4 font-black text-lg transition-colors ${visualTab === 'questions' ? 'text-blue-600 border-b-4 border-blue-600 bg-blue-50/30' : 'text-gray-500 hover:bg-gray-50'}`}
                  >
                    📖 题目管理 ({data.questions?.length || 0})
                  </button>
                  <button 
                    onClick={() => setVisualTab('results')}
                    className={`flex-1 py-4 font-black text-lg transition-colors ${visualTab === 'results' ? 'text-green-600 border-b-4 border-green-600 bg-green-50/30' : 'text-gray-500 hover:bg-gray-50'}`}
                  >
                    🏆 结果分支 ({data.results?.length || 0})
                  </button>
                </div>

                {/* 题目栏 */}
                {visualTab === 'questions' && (
                  <div className="w-full pb-12">
                    <div className="flex justify-between items-center mb-6">
                      <p className="text-gray-500 text-sm">在这里编辑所有的题目及其选项权重。</p>
                      <button onClick={addQuestion} className="bg-blue-600 text-white hover:bg-blue-700 px-4 py-2 rounded font-bold shadow-sm transition-colors">+ 添加题目</button>
                    </div>
                    <div className="grid grid-cols-1 gap-3">
                      {(data.questions || []).map((q: any, qIdx: number) => (
                        <div key={q.id} className="border border-blue-100 rounded p-3 bg-white shadow-sm relative">
                          <button onClick={() => removeQuestion(qIdx)} className="absolute top-2 right-2 text-gray-300 hover:text-red-500 font-bold text-xl leading-none">&times;</button>
                          <div className="mb-2 pr-6 flex items-start gap-2">
                            <span className="bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded text-xs font-black shrink-0 mt-1">Q{qIdx + 1}</span>
                            <textarea 
                              value={q.text} 
                              onChange={e => updateQuestion(qIdx, 'text', e.target.value)}
                              placeholder="请输入题目内容..."
                              className="flex-1 border border-gray-300 rounded p-1.5 focus:border-blue-500 outline-none text-gray-900 font-bold text-sm"
                              rows={1}
                              style={{ minHeight: '34px' }}
                            />
                          </div>
                          <div className="pl-7 space-y-1">
                            {(q.options || []).map((opt: any, oIdx: number) => (
                              <div key={opt.id} className="flex flex-col bg-gray-50 p-1.5 border border-gray-200 rounded relative group">
                                <button onClick={() => removeOption(qIdx, oIdx)} className="absolute top-1/2 -translate-y-1/2 right-2 text-gray-300 hover:text-red-500 font-bold text-lg leading-none opacity-0 group-hover:opacity-100">&times;</button>
                                <div className="flex items-center gap-2 pr-6">
                                  <span className="text-[10px] text-gray-400 font-bold w-3 text-center">{oIdx + 1}</span>
                                  <input 
                                    type="text" 
                                    value={opt.text} 
                                    onChange={e => updateOption(qIdx, oIdx, 'text', e.target.value)}
                                    placeholder="选项文案"
                                    className="flex-1 border border-gray-200 bg-white focus:border-blue-500 rounded p-1 outline-none text-sm font-medium"
                                  />
                                </div>
                                <div className="flex flex-wrap gap-1.5 pl-5 mt-1">
                                  {Object.entries(opt).map(([k, v]) => {
                                    if (k === 'id' || k === 'text') return null;
                                    return (
                                      <div key={k} className="flex items-center gap-1 bg-white border border-gray-200 rounded px-1">
                                        <label className="text-[9px] text-gray-400 font-mono truncate max-w-[60px]" title={k}>{k}</label>
                                        <input 
                                          type={typeof v === 'number' ? 'number' : 'text'}
                                          value={v as string | number}
                                          onChange={e => updateOption(qIdx, oIdx, k, typeof v === 'number' ? Number(e.target.value) : e.target.value)}
                                          className="w-16 border-none py-0 text-xs outline-none focus:ring-1 focus:ring-blue-500 bg-transparent text-gray-800"
                                        />
                                      </div>
                                    );
                                  })}
                                </div>
                              </div>
                            ))}
                            <button onClick={() => addOption(qIdx)} className="text-blue-600 hover:text-blue-800 text-xs font-bold flex items-center gap-1 mt-1 px-1 py-0.5 rounded hover:bg-blue-50 inline-block">
                              + 新增选项
                            </button>
                          </div>
                        </div>
                      ))}
                      {(!data.questions || data.questions.length === 0) && (
                        <div className="text-center py-16 bg-gray-50 border-2 border-dashed border-gray-200 rounded-lg">
                          <p className="text-gray-400 font-medium">暂无题目，点击右上角添加或在 JSON 中粘贴。</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* 结果栏 */}
                {visualTab === 'results' && (
                  <div className="w-full pb-12">
                    <div className="flex justify-between items-center mb-6">
                      <p className="text-gray-500 text-sm">在这里编辑所有的测试结果分支和对应文案。</p>
                      <button onClick={addResult} className="bg-green-600 text-white hover:bg-green-700 px-4 py-2 rounded font-bold shadow-sm transition-colors">+ 添加结果</button>
                    </div>
                    <div className="grid grid-cols-1 gap-3">
                      {(data.results || []).map((r: any, rIdx: number) => (
                        <div key={r.id} className="border border-green-200 rounded p-3 bg-green-50/20 shadow-sm relative">
                          <button onClick={() => removeResult(rIdx)} className="absolute top-2 right-2 text-gray-300 hover:text-red-500 font-bold text-xl leading-none">&times;</button>
                          <div className="flex flex-col gap-2 pr-6">
                            <div className="flex items-center gap-2">
                              <span className="bg-green-100 text-green-700 px-1.5 py-0.5 rounded text-xs font-black shrink-0">R{rIdx + 1}</span>
                              <input 
                                type="text" 
                                value={r.title} 
                                onChange={e => updateResult(rIdx, 'title', e.target.value)}
                                placeholder="结果标题 (例如：INTJ 专家型)"
                                className="flex-1 border border-green-200 rounded p-1 focus:border-green-500 outline-none text-gray-900 font-bold text-sm bg-white"
                              />
                            </div>
                            <div className="flex flex-wrap gap-1.5 pl-8">
                              {Object.entries(r).map(([k, v]) => {
                                if (k === 'id' || k === 'title' || k === 'description') return null;
                                return (
                                  <div key={k} className="flex items-center gap-1 bg-white border border-gray-200 rounded px-1">
                                    <label className="text-[9px] text-gray-400 font-mono truncate max-w-[60px]" title={k}>{k}</label>
                                    <input 
                                      type={typeof v === 'number' ? 'number' : 'text'}
                                      value={v as string | number}
                                      onChange={e => updateResult(rIdx, k, typeof v === 'number' ? Number(e.target.value) : e.target.value)}
                                      className="w-20 border-none py-0 text-xs outline-none focus:ring-1 focus:ring-green-500 bg-transparent text-gray-800"
                                    />
                                  </div>
                                );
                              })}
                            </div>
                            <div className="pl-8">
                              <textarea 
                                value={r.description} 
                                onChange={e => updateResult(rIdx, 'description', e.target.value)}
                                placeholder="请输入深度解析文案..."
                                className="w-full border border-green-200 rounded p-1.5 focus:border-green-500 outline-none text-gray-800 text-xs leading-relaxed bg-white"
                                rows={2}
                              />
                            </div>
                          </div>
                        </div>
                      ))}
                      {(!data.results || data.results.length === 0) && (
                        <div className="text-center py-16 bg-gray-50 border-2 border-dashed border-gray-200 rounded-lg">
                          <p className="text-gray-400 font-medium">暂无结果分支，点击右上角添加。</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
