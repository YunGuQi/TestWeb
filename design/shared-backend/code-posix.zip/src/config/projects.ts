export const TEST_PROJECTS = [
  { 
    id: 'emotional-friction-test', 
    testId: 'emotional-friction', 
    name: '情绪摩擦力测试', 
    baseCount: 1541 
  },
  { 
    id: 'dating-style-test', 
    testId: 'dating-style', 
    name: '恋爱风格测试', 
    baseCount: 1200 
  }
];
