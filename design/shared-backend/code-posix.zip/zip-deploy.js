const fs = require('fs');
const { ZipArchive } = require('archiver');
const path = require('path');

const output = fs.createWriteStream(path.join(__dirname, 'code-posix.zip'));
const archive = new ZipArchive({
  zlib: { level: 9 } // Sets the compression level.
});

output.on('close', function() {
  console.log('✅ 打包成功! 总字节数: ' + archive.pointer());
  console.log('请将生成的 code-posix.zip 上传至云开发控制台进行部署。');
});

archive.on('warning', function(err) {
  if (err.code === 'ENOENT') {
    console.warn('警告:', err);
  } else {
    throw err;
  }
});

archive.on('error', function(err) {
  throw err;
});

archive.pipe(output);

// Add everything except heavy build folders
archive.glob('**/*', {
  cwd: __dirname,
  ignore: [
    'node_modules/**',
    '.next/**',
    'deploy.zip',
    'code-posix.zip',
    'code.zip',
    '*.log.txt',
    '.git/**'
  ],
  dot: true 
});

archive.finalize();
