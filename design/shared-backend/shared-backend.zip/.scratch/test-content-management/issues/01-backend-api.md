# 01 — 01-backend-api

**What to build:** 搭建好 JSON 文件的读写底层逻辑。提供 `GET /api/content` 供前端拉取数据，以及 `POST /api/admin/content` 供后台更新并覆盖 JSON 文件。所有文件存储在 `src/config/tests/[testId].json` 中。如果 `[testId].json` 不存在，GET请求能返回空或默认模板。

**Blocked by:** None — can start immediately

**Status:** ready-for-agent

- [ ] Create `src/config/tests` directory.
- [ ] Create `src/app/api/content/route.ts` handling `GET` with `testId` query param.
- [ ] Create `src/app/api/admin/content/route.ts` handling `GET` and `POST` with `testId` query param.
