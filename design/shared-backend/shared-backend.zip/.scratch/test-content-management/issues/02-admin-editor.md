# 02 — 02-admin-editor

**What to build:** 在 `/admin` 项目统计列表中新增内容入口；完成 `/admin/content/[testId]/page.tsx` 页面；实现图形化表单（题目、选项、结果）的增删改，以及与 JSON 纯文本之间的双向转换和提交保存。

**Blocked by:** 01-backend-api

**Status:** ready-for-agent

- [ ] Modify `src/app/admin/ProjectStats.tsx` to add links to the content editor.
- [ ] Create `src/app/admin/content/[testId]/page.tsx` with a visual/JSON hybrid editor.
- [ ] Verify data can be saved and loaded properly via the API created in ticket 01.
